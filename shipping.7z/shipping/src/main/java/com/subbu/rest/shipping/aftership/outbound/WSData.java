package com.subbu.rest.shipping.aftership.outbound;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WSData {
	
	private WSTracking tracking;

}
