package com.subbu.rest.shipping.service;

public interface ShippingService {
	
	ShipmentResponseVO createShipment(CreateShipmentRequestVO requestVO) throws Exception;
	
	ShipmentResponseVO getShipmentDetails(String trackingNumber, String courierId) throws Exception;

}
