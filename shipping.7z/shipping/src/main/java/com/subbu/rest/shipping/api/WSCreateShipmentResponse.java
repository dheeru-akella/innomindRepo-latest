package com.subbu.rest.shipping.api;

import com.subbu.rest.shipping.service.ShipmentResponseVO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class WSCreateShipmentResponse {

	private String trackingNumber;
	private String currentStatus;

	public WSCreateShipmentResponse(ShipmentResponseVO shipment) {
		this.setCurrentStatus(shipment.getCurrentStatus());
		this.setTrackingNumber(shipment.getTrackingNumber());
	}
}
