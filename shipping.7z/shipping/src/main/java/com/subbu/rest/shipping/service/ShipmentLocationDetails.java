package com.subbu.rest.shipping.service;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ShipmentLocationDetails {
	
	private String trackingNumber;
	private String origin;
	private String destination;

}
