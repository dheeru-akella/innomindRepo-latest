package com.subbu.rest.shipping.aftership.outbound;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WSTracking {

	private String tracking_number;
	private String slug;
	private String destinationCountry;
	private String originCountry;
	private String tag;
	private String id;
}
