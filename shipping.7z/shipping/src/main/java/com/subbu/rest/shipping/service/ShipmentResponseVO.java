package com.subbu.rest.shipping.service;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ShipmentResponseVO {

	private String id;
	private String origin;
	private String courierCode;
	private String trackingNumber;
	private String destination;
	private String currentStatus;

}
