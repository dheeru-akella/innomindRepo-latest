package com.subbu.rest.shipping.util;

public class DataValidationException extends Exception {

	private static final long serialVersionUID = 1L;

	private String fieldName;
	private String errorCode;
	private boolean isRecordNotFound;
	private boolean isUnknownError;

	public DataValidationException() {
		super();
	}

	public DataValidationException(String fieldName, String errorCode) {
		super();
		this.fieldName = fieldName;
		this.errorCode = errorCode;
	}

	public DataValidationException(String fieldName, String errorCode, boolean isRecordNotFound) {
		super();
		this.fieldName = fieldName;
		this.errorCode = errorCode;
		this.isRecordNotFound = isRecordNotFound;
	}

	public DataValidationException(boolean isUnknownError) {
		super();
		this.isUnknownError = isUnknownError;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public boolean isRecordNotFound() {
		return isRecordNotFound;
	}

	public void setRecordNotFound(boolean isRecordNotFound) {
		this.isRecordNotFound = isRecordNotFound;
	}

	public boolean isUnknownError() {
		return isUnknownError;
	}

	public void setUnknownError(boolean isUnknownError) {
		this.isUnknownError = isUnknownError;
	}

}
