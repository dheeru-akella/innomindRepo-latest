package com.subbu.rest.shipping.util;

import java.io.IOException;

import org.springframework.http.client.ClientHttpResponse;

public class AftershipErrorHandler{

	public boolean hasError(ClientHttpResponse response) throws IOException {
		return false;
	}

	public void handleError(ClientHttpResponse httpResponse) throws IOException {
		
	}

}
