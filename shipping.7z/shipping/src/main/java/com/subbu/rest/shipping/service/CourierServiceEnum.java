package com.subbu.rest.shipping.service;

public enum CourierServiceEnum {
	FEDEX("FedEx"), UPS("UPS"), USPS("USPS");

	private String name;

	CourierServiceEnum(String name) {
		this.name = name;
	}

	private String getName() {
		return name;
	}

	public static String getCourierServiceName(String name) {
		for (CourierServiceEnum courier : CourierServiceEnum.values()) {
			if (courier.getName().equalsIgnoreCase(name)) {
				return courier.getName();
			}
		}
		return null;
	}

}
