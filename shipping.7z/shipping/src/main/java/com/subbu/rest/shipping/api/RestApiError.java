package com.subbu.rest.shipping.api;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class RestApiError{
	
	private String fieldName;
	private String errorMessage;
	
	public RestApiError(String fieldName, String errorCode) {
		this.fieldName = fieldName;
		this.errorMessage = errorCode;
	}	

}
