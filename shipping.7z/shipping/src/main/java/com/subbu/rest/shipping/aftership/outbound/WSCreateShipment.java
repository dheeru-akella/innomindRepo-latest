package com.subbu.rest.shipping.aftership.outbound;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WSCreateShipment {

	private WSTracking tracking;
}
