package com.subbu.rest.shipping.aftership.outbound;

import com.subbu.rest.shipping.service.ShipmentResponseVO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WSCreateShipmentResponse extends WSBaseAftershipResponse{
	
	private WSData data;
	
	public ShipmentResponseVO toVO() {
		ShipmentResponseVO vo = new ShipmentResponseVO();
		if(null != data && null != data.getTracking()) {
			vo.setCurrentStatus(data.getTracking().getTag());
			vo.setTrackingNumber(data.getTracking().getTracking_number());
			vo.setCourierCode(data.getTracking().getSlug());
			vo.setId(data.getTracking().getId());
		}
		return vo;
	}

}
