package com.subbu.rest.shipping.api;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.subbu.rest.shipping.service.ShipmentResponseVO;
import com.subbu.rest.shipping.service.ShippingService;
import com.subbu.rest.shipping.util.DataValidationException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class ShippingApi {

	private ShippingService shippingService;

	@Autowired
	public void setShippingService(ShippingService shippingService) {
		this.shippingService = shippingService;
	}

	@PostMapping("/shipment")
	private ResponseEntity<WSCreateShipmentResponse> createShipment(@RequestBody WSCreateShipmentRequest request) throws Exception {
		log.debug("in create shipment");
		ShipmentResponseVO responseVO = shippingService.createShipment(request.toVO());
		WSCreateShipmentResponse response = new WSCreateShipmentResponse(responseVO);
		return new ResponseEntity<WSCreateShipmentResponse>(response, HttpStatus.CREATED);
	}

	@GetMapping("/courier/{courierId}/shipment/{shipmentId}")
	private ResponseEntity<WSGetShipmentDetailsResponse> getShipDetails(@PathVariable("shipmentId") String shipmentId,
			@PathVariable("courierId") String courierId) throws Exception {
		log.debug("in get shipment");
		ShipmentResponseVO responseVO = shippingService.getShipmentDetails(shipmentId, courierId);
		WSGetShipmentDetailsResponse response = new WSGetShipmentDetailsResponse(responseVO);
		return new ResponseEntity<WSGetShipmentDetailsResponse>(response, HttpStatus.OK);
	}

	@ResponseBody
	@ExceptionHandler({ DataValidationException.class })
	public ResponseEntity<Object> handleDataValidationException(DataValidationException exception) {
		RestApiError ex = new RestApiError(exception.getFieldName(), exception.getErrorCode());
		if (exception.isRecordNotFound()) {
			return new ResponseEntity<Object>(ex, HttpStatus.NOT_FOUND);
		}else if(exception.isUnknownError()) {
			return new ResponseEntity<Object>(ex, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(ex, HttpStatus.BAD_REQUEST);
	}
	
	@ResponseBody
	@ExceptionHandler({ Exception.class })
	public ResponseEntity<Object> handleUnknownException(Exception exception) {
		log.debug("unknown exception", exception);
		RestApiError ex = new RestApiError("", "");
		return new ResponseEntity<Object>(ex, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
