package com.subbu.rest.shipping.api;

import com.subbu.rest.shipping.service.CreateShipmentRequestVO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WSCreateShipmentRequest {
	
	private String origin;
	private String courierCode;
	private String trackingNumber;
	private String destination;
	
	public CreateShipmentRequestVO toVO() {
		CreateShipmentRequestVO vo = new CreateShipmentRequestVO();
		vo.setTrackingNumber(getTrackingNumber());
		vo.setCourierCode(courierCode);
		vo.setOrigin(origin);
		vo.setDestination(destination);
		return vo;
	}

}
