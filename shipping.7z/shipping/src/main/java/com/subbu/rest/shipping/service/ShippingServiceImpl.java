package com.subbu.rest.shipping.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;

import com.subbu.rest.shipping.util.AftershipApiProxy;
import com.subbu.rest.shipping.util.DataValidationException;

@Component
public class ShippingServiceImpl implements ShippingService {

	private final String GET_LOCATION_DETAILS = "select * from SHIPMENTS where tracking_number = ?";

	@Autowired
	private AftershipApiProxy proxy;

	@Autowired
	private DataSource dataSource;

	@Override
	public ShipmentResponseVO createShipment(CreateShipmentRequestVO requestVO) throws Exception {
		validateCreateShipmentRequest(requestVO);
		ShipmentResponseVO responseVO = proxy.createShipment(requestVO);
		if (null != responseVO) {
			persistTrackingLocaationDetails(requestVO);
		}
		return responseVO;
	}

	private void persistTrackingLocaationDetails(CreateShipmentRequestVO requestVO) {
		try {
			SimpleJdbcInsert insert = new SimpleJdbcInsert(getJdbcTemplate());
			Map<String, String> rowDeatils = new HashMap<>(3);
			rowDeatils.put("tracking_number", requestVO.getTrackingNumber());
			rowDeatils.put("origin", requestVO.getOrigin());
			rowDeatils.put("destination", requestVO.getDestination());
			insert.withTableName("SHIPMENTS").execute(rowDeatils);
		} catch (Exception e) {
			// do nothing, as its temporary
		}
	}

	private void validateCreateShipmentRequest(CreateShipmentRequestVO requestVO) throws DataValidationException {
		if (StringUtils.isBlank(requestVO.getTrackingNumber())) {
			throw new DataValidationException("trackingNumber", "value required");
		}

		if (StringUtils.isBlank(requestVO.getCourierCode())) {
			throw new DataValidationException("courierCode", "value required");
		}

		String courier = CourierServiceEnum.getCourierServiceName(requestVO.getCourierCode());

		if (null == courier) {
			throw new DataValidationException("courierCode", "unsupported courier code");
		}

		if (StringUtils.isBlank(requestVO.getOrigin())) {
			throw new DataValidationException("origin", "value required");
		}

		if (StringUtils.isBlank(requestVO.getDestination())) {
			throw new DataValidationException("destination", "value required");
		}
	}

	@Override
	public ShipmentResponseVO getShipmentDetails(String trackingNumber, String courierId) throws Exception {
		ShipmentResponseVO responseVO = proxy.getShipmentDetails(trackingNumber, courierId);
		try {
			ShipmentLocationDetails locationDetails = getLocationDetails(trackingNumber);
			if (null != locationDetails) {
				responseVO.setDestination(locationDetails.getDestination());
				responseVO.setOrigin(locationDetails.getOrigin());
			}
		} catch (Exception e) {
			// do nothing, as its temporary
		}
		return responseVO;
	}

	@SuppressWarnings(value = { "all" })
	private ShipmentLocationDetails getLocationDetails(String trackingId) {
		ShipmentLocationDetails locationDetails = getJdbcTemplate().queryForObject(GET_LOCATION_DETAILS,
				new Object[] { trackingId }, new RowMapper<ShipmentLocationDetails>() {
					@Override
					public ShipmentLocationDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
						if (null == rs) {
							return null;
						}
						ShipmentLocationDetails vo = new ShipmentLocationDetails();
						vo.setDestination(rs.getString("destination"));
						vo.setOrigin(rs.getString("origin"));
						vo.setTrackingNumber(rs.getString("tracking_number"));
						return vo;
					}
				});
		return locationDetails;
	}

	private JdbcTemplate getJdbcTemplate() {
		JdbcTemplate template = new JdbcTemplate(dataSource);
		return template;
	}

}
