package com.subbu.rest.shipping.util;

import java.util.Collections;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.subbu.rest.shipping.aftership.outbound.WSBaseAftershipResponse;
import com.subbu.rest.shipping.aftership.outbound.WSCreateShipment;
import com.subbu.rest.shipping.aftership.outbound.WSCreateShipmentResponse;
import com.subbu.rest.shipping.aftership.outbound.WSTracking;
import com.subbu.rest.shipping.service.CreateShipmentRequestVO;
import com.subbu.rest.shipping.service.ShipmentResponseVO;

@Component
public class AftershipApiProxy {

	private String CREATE_SHIPMENT = "/trackings";
	private String GET_SHIPMENT_DETAILS = "/trackings/{courierId}/{trackingId}";

	private RestTemplate restTemplate;

	@Autowired
	private Environment environment;

	@Autowired
	private ObjectMapper jsonMapper;

	public ShipmentResponseVO createShipment(CreateShipmentRequestVO request) throws DataValidationException {
		ShipmentResponseVO shipmentDetails = null;
		try {
			WSCreateShipment outboundReq = new WSCreateShipment();
			outboundReq.setTracking(new WSTracking());
			outboundReq.getTracking().setTracking_number(request.getTrackingNumber());
			outboundReq.getTracking().setSlug(request.getCourierCode());
			// remaining fields needs clarification to set
			ResponseEntity<WSCreateShipmentResponse> response = getRestTemplate().exchange(
					getBaseUrl() + CREATE_SHIPMENT, HttpMethod.POST,
					new HttpEntity<WSCreateShipment>(outboundReq, getHeaders()), WSCreateShipmentResponse.class);
			if (response.getStatusCode() != HttpStatus.CREATED) {
				handleErrorsInResponse(response);
			}
			shipmentDetails = response.getBody().toVO();
		} catch (HttpStatusCodeException exception) {
			handleExceptionBasedOnStatus(exception);
		} catch (Exception e) {
			throw new DataValidationException(true);
		}
		return shipmentDetails;
	}

	public ShipmentResponseVO getShipmentDetails(String shipmentId, String courierId) throws DataValidationException {
		ShipmentResponseVO shipmentDetails = null;
		try {
			ResponseEntity<WSCreateShipmentResponse> response = getRestTemplate().exchange(
					getBaseUrl() + GET_SHIPMENT_DETAILS, HttpMethod.GET, new HttpEntity<>(getHeaders()),
					WSCreateShipmentResponse.class, courierId, shipmentId);

			if (response.getStatusCode() != HttpStatus.OK) {
				handleErrorsInResponse(response);
			}
			shipmentDetails = response.getBody().toVO();
		} catch (HttpStatusCodeException exception) {
			handleExceptionBasedOnStatus(exception);
		} catch (Exception e) {
			throw new DataValidationException(true);
		}
		return shipmentDetails;
	}

	private void handleExceptionBasedOnStatus(HttpStatusCodeException exception) throws DataValidationException {
		String responseString = exception.getResponseBodyAsString();
		String errorMessage = "";
		if (StringUtils.isNotBlank(responseString)) {
			try {
				WSBaseAftershipResponse errorResponse = jsonMapper.readValue(responseString,
						WSBaseAftershipResponse.class);
				if (null != errorResponse) {
					errorMessage = errorResponse.getMeta().getMessage();
				}
			} catch (Exception e) {
				// nothing for now
			}
		}
		if (exception.getStatusCode() == HttpStatus.BAD_REQUEST) {
			throw new DataValidationException("", errorMessage);
		} else if (exception.getStatusCode() == HttpStatus.NOT_FOUND) {
			throw new DataValidationException("", errorMessage, true);
		} else {
			throw new DataValidationException(true);
		}
	}

	private void handleErrorsInResponse(ResponseEntity<WSCreateShipmentResponse> response)
			throws DataValidationException {
		// a generic error mapping can be done here. for now its 400 and 404 are being
		// handled
		if (response.getStatusCode() == HttpStatus.BAD_REQUEST) {
			throw new DataValidationException("", response.getBody().getMeta().getMessage());
		} else if (response.getStatusCode() == HttpStatus.NOT_FOUND) {
			throw new DataValidationException("", response.getBody().getMeta().getMessage(), true);
		} else {
			throw new DataValidationException(true);
		}
	}

	private RestTemplate getRestTemplate() {
		if (null == restTemplate) {
			restTemplate = new RestTemplate();
		}
		return restTemplate;
	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		headers.set("aftership-api-key", environment.getProperty("aftership.api.key"));
		return headers;
	}

	private String getBaseUrl() {
		return environment.getProperty("aftership.api.base-url");
	}

}
