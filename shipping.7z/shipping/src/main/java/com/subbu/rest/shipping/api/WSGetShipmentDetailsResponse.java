package com.subbu.rest.shipping.api;

import com.subbu.rest.shipping.service.ShipmentResponseVO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class WSGetShipmentDetailsResponse {

	private String id;
	private String origin;
	private String courierCode;
	private String trackingNumber;
	private String destination;
	private String currentStatus;
	
	public WSGetShipmentDetailsResponse(ShipmentResponseVO shipmentDetails) {
		setCurrentStatus(shipmentDetails.getCurrentStatus());
		setTrackingNumber(shipmentDetails.getTrackingNumber());
		setCourierCode(shipmentDetails.getCourierCode());
		setDestination(shipmentDetails.getDestination());
		setId(shipmentDetails.getId());
		setOrigin(shipmentDetails.getOrigin());
	}

}
