package com.subbu.rest.shipping;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.URL;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.subbu.rest.shipping.api.RestApiError;
import com.subbu.rest.shipping.api.WSCreateShipmentRequest;
import com.subbu.rest.shipping.api.WSCreateShipmentResponse;
import com.subbu.rest.shipping.api.WSGetShipmentDetailsResponse;
import com.subbu.rest.shipping.service.ShipmentResponseVO;
import com.subbu.rest.shipping.util.AftershipApiProxy;
import com.subbu.rest.shipping.util.DataValidationException;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class ShippingApplicationTests {

	@LocalServerPort
	private int port;

	@MockBean
	private AftershipApiProxy proxy;

	@Autowired
	private TestRestTemplate restTemplate;

	@Test
	public void testGetShipmentTrackingDetails_200_status() throws Exception {
		ShipmentResponseVO vo = new ShipmentResponseVO();
		vo.setCourierCode("abcd");
		vo.setTrackingNumber("123");
		vo.setCurrentStatus("pending");
		Mockito.when(proxy.getShipmentDetails("123", "abcd")).thenReturn(vo);
		ResponseEntity<WSGetShipmentDetailsResponse> response = restTemplate.getForEntity(
				new URL("http://localhost:" + port + "/courier/abcd/shipment/123").toString(),
				WSGetShipmentDetailsResponse.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(response.getBody().getCourierCode(), vo.getCourierCode());
		assertEquals(response.getBody().getCurrentStatus(), vo.getCurrentStatus());
		assertEquals(response.getBody().getTrackingNumber(), vo.getTrackingNumber());
	}

	@Test
	public void testGetShipmentTrackingDetails_400_status() throws Exception {
		Mockito.when(proxy.getShipmentDetails("123", "abcd"))
				.thenThrow(new DataValidationException("", "invalid courier"));
		ResponseEntity<RestApiError> response = restTemplate.getForEntity(
				new URL("http://localhost:" + port + "/courier/abcd/shipment/123").toString(), RestApiError.class);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertEquals(response.getBody().getErrorMessage(), "invalid courier");
	}

	@Test
	public void testGetShipmentTrackingDetails_404_status() throws Exception {
		Mockito.when(proxy.getShipmentDetails("123", "abcd"))
				.thenThrow(new DataValidationException("", "no shipment found", true));
		ResponseEntity<RestApiError> response = restTemplate.getForEntity(
				new URL("http://localhost:" + port + "/courier/abcd/shipment/123").toString(), RestApiError.class);
		assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
		assertEquals(response.getBody().getErrorMessage(), "no shipment found");
	}

	@Test
	public void testCreateShipping_400_status() throws Exception {
		WSCreateShipmentRequest request = new WSCreateShipmentRequest();
		assertDataValidationError(request, "trackingNumber", "value required");
		request.setTrackingNumber("1234");
		assertDataValidationError(request, "courierCode", "value required");
		request.setCourierCode("USPS");
		assertDataValidationError(request, "origin", "value required");
		request.setOrigin("test");
		assertDataValidationError(request, "destination", "value required");

	}

	private void assertDataValidationError(WSCreateShipmentRequest request, String errorField, String error)
			throws Exception {
		ResponseEntity<RestApiError> response = restTemplate
				.postForEntity(new URL("http://localhost:" + port + "/shipment").toURI(), request, RestApiError.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getBody().getFieldName(), errorField);
		assertEquals(response.getBody().getErrorMessage(), error);
	}

	@Test
	public void testCreateShipment_200_status() throws Exception {
		ShipmentResponseVO vo = new ShipmentResponseVO();
		vo.setTrackingNumber("123");
		vo.setCurrentStatus("pending");
		Mockito.when(proxy.createShipment(Mockito.any())).thenReturn(vo);

		WSCreateShipmentRequest request = new WSCreateShipmentRequest();
		request.setTrackingNumber("1234");
		request.setCourierCode("USPS");
		request.setOrigin("test");
		request.setDestination("test");

		ResponseEntity<WSCreateShipmentResponse> response = restTemplate.postForEntity(
				new URL("http://localhost:" + port + "/shipment").toURI(), request, WSCreateShipmentResponse.class);
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertEquals(response.getBody().getCurrentStatus(), vo.getCurrentStatus());
		assertEquals(response.getBody().getTrackingNumber(), vo.getTrackingNumber());
	}

}
